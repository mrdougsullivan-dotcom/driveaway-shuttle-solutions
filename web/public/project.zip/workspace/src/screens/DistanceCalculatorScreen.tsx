import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, ActivityIndicator } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '@/navigation/types';
import { Calculator, MapPin, Navigation } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

type Props = NativeStackScreenProps<RootStackParamList, 'DistanceCalculator'>;

interface DistanceResult {
  distance: number;
  duration: string;
  fromCity: string;
  toCity: string;
}

const DistanceCalculatorScreen = ({ navigation }: Props) => {
  const [dropOffCity, setDropOffCity] = useState('');
  const [pickupCity, setPickupCity] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DistanceResult | null>(null);
  const [error, setError] = useState('');

  // Simple distance calculation using Haversine formula
  const calculateDistance = async () => {
    if (!dropOffCity.trim() || !pickupCity.trim()) {
      setError('Please enter both cities');
      return;
    }

    setLoading(true);
    setError('');
    setResult(null);

    try {
      // Get coordinates for both cities using a geocoding service
      const fromCoords = await geocodeCity(dropOffCity);
      const toCoords = await geocodeCity(pickupCity);

      if (!fromCoords || !toCoords) {
        setError('Could not find one or both cities. Please check spelling and include state (e.g., "Macungie, PA")');
        setLoading(false);
        return;
      }

      // Calculate distance using Haversine formula
      const distance = haversineDistance(
        fromCoords.lat,
        fromCoords.lng,
        toCoords.lat,
        toCoords.lng
      );

      // Estimate driving time (assuming average speed of 60 mph)
      const hours = Math.floor(distance / 60);
      const minutes = Math.round((distance / 60 - hours) * 60);
      const duration = hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;

      setResult({
        distance: Math.round(distance),
        duration,
        fromCity: dropOffCity,
        toCity: pickupCity
      });
    } catch (err) {
      setError('Error calculating distance. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Geocode city using OpenStreetMap Nominatim (free, no API key needed)
  const geocodeCity = async (city: string): Promise<{ lat: number; lng: number } | null> => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)}&format=json&limit=1`,
        {
          headers: {
            'User-Agent': 'DriveawayShuttleSolutions/1.0'
          }
        }
      );
      const data = await response.json();

      if (data && data.length > 0) {
        return {
          lat: parseFloat(data[0].lat),
          lng: parseFloat(data[0].lon)
        };
      }
      return null;
    } catch (error) {
      console.error('Geocoding error:', error);
      return null;
    }
  };

  // Haversine formula to calculate distance between two coordinates
  const haversineDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959; // Earth's radius in miles
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);

    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const toRad = (degrees: number): number => {
    return degrees * (Math.PI / 180);
  };

  const clearForm = () => {
    setDropOffCity('');
    setPickupCity('');
    setResult(null);
    setError('');
  };

  return (
    <View className="flex-1 bg-slate-50">
      <ScrollView className="flex-1">
        {/* Header */}
        <LinearGradient
          colors={["#3b82f6", "#2563eb"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ paddingHorizontal: 16, paddingTop: 60, paddingBottom: 32 }}
        >
          <View className="flex-row items-center gap-3 mb-2">
            <Calculator size={32} color="#ffffff" strokeWidth={2.5} />
            <Text className="text-3xl font-bold text-white">
              Distance Calculator
            </Text>
          </View>
          <Text className="text-blue-100 text-base">
            Calculate distance from drop-off to pickup location
          </Text>
        </LinearGradient>

        <View className="px-4 py-6">
          {/* Instructions */}
          <View className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
            <Text className="text-blue-900 font-semibold mb-2">How to use:</Text>
            <Text className="text-blue-800 text-sm">
              1. Enter your vehicle drop-off city (where you deliver the load)
              {'\n'}2. Enter the pickup city (where shuttle drivers are located)
              {'\n'}3. Tap Calculate to see the distance
            </Text>
          </View>

          {/* Drop-off Location */}
          <View className="mb-6">
            <View className="flex-row items-center gap-2 mb-2">
              <MapPin size={20} color="#64748b" />
              <Text className="text-slate-700 font-semibold text-lg">
                Drop-off Location
              </Text>
            </View>
            <TextInput
              value={dropOffCity}
              onChangeText={setDropOffCity}
              placeholder="e.g., Macungie, PA"
              className="bg-white border-2 border-slate-300 rounded-xl px-4 py-4 text-lg text-slate-900"
              placeholderTextColor="#94a3b8"
              autoCapitalize="words"
              autoCorrect={false}
              textContentType="addressCity"
            />
            <Text className="text-slate-500 text-sm mt-1 ml-1">
              Where you&apos;re delivering the vehicle
            </Text>
          </View>

          {/* Pickup Location */}
          <View className="mb-6">
            <View className="flex-row items-center gap-2 mb-2">
              <Navigation size={20} color="#64748b" />
              <Text className="text-slate-700 font-semibold text-lg">
                Shuttle Pickup Location
              </Text>
            </View>
            <TextInput
              value={pickupCity}
              onChangeText={setPickupCity}
              placeholder="e.g., Hollidaysburg, PA"
              className="bg-white border-2 border-slate-300 rounded-xl px-4 py-4 text-lg text-slate-900"
              placeholderTextColor="#94a3b8"
              autoCapitalize="words"
              autoCorrect={false}
              textContentType="addressCity"
            />
            <Text className="text-slate-500 text-sm mt-1 ml-1">
              Where shuttle drivers are located
            </Text>
          </View>

          {/* Calculate Button */}
          <Pressable
            onPress={calculateDistance}
            disabled={loading}
            className="active:opacity-80 mb-4"
          >
            <LinearGradient
              colors={["#3b82f6", "#2563eb"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                borderRadius: 16,
                padding: 18,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: 8,
                shadowColor: "#3b82f6",
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.3,
                shadowRadius: 12,
                elevation: 6,
              }}
            >
              {loading ? (
                <ActivityIndicator color="#ffffff" />
              ) : (
                <>
                  <Calculator size={24} color="#ffffff" strokeWidth={2.5} />
                  <Text className="text-white font-bold text-lg">
                    Calculate Distance
                  </Text>
                </>
              )}
            </LinearGradient>
          </Pressable>

          {/* Clear Button */}
          {(dropOffCity || pickupCity || result) && (
            <Pressable
              onPress={clearForm}
              className="bg-slate-200 rounded-xl py-4 active:opacity-80"
            >
              <Text className="text-slate-700 font-semibold text-center">
                Clear
              </Text>
            </Pressable>
          )}

          {/* Error Message */}
          {error ? (
            <View className="bg-red-50 border border-red-200 rounded-xl p-4 mt-4">
              <Text className="text-red-800 font-medium">{error}</Text>
            </View>
          ) : null}

          {/* Result */}
          {result ? (
            <View className="mt-6">
              <LinearGradient
                colors={["#10b981", "#059669"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{
                  borderRadius: 20,
                  padding: 24,
                  shadowColor: "#10b981",
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.3,
                  shadowRadius: 12,
                  elevation: 8,
                }}
              >
                <Text className="text-white text-lg font-semibold mb-4">
                  Distance Result:
                </Text>

                <View className="bg-white/20 rounded-xl p-4 mb-3">
                  <Text className="text-white/80 text-sm mb-1">From:</Text>
                  <Text className="text-white font-bold text-xl">{result.fromCity}</Text>
                </View>

                <View className="bg-white/20 rounded-xl p-4 mb-4">
                  <Text className="text-white/80 text-sm mb-1">To:</Text>
                  <Text className="text-white font-bold text-xl">{result.toCity}</Text>
                </View>

                <View className="bg-white/30 rounded-xl p-6">
                  <Text className="text-white text-center text-5xl font-bold mb-2">
                    {result.distance}
                  </Text>
                  <Text className="text-white text-center text-xl font-semibold">
                    miles
                  </Text>
                  <Text className="text-white/90 text-center text-lg mt-3">
                    Est. driving time: {result.duration}
                  </Text>
                </View>

                <Text className="text-white/80 text-sm text-center mt-4">
                  * Distance is calculated as the crow flies. Actual driving distance may vary.
                </Text>
              </LinearGradient>

              {/* Find Shuttle Drivers Button */}
              <Pressable
                onPress={() => navigation.navigate('MapScreen')}
                className="mt-4 bg-blue-600 rounded-xl py-4 active:opacity-80"
              >
                <Text className="text-white font-bold text-center text-lg">
                  Find Shuttle Drivers Near {result.toCity}
                </Text>
              </Pressable>
            </View>
          ) : null}
        </View>
      </ScrollView>
    </View>
  );
};

export default DistanceCalculatorScreen;
