import { PrismaClient } from "../generated/prisma";

const prisma = new PrismaClient();

// Real driveaway companies from driveawayguide.com map
const realDrivers = [
  // Arizona
  {
    name: "Blythe to Ehrenburg Shuttle",
    phoneNumber: "Melo: (928) 315-8777, Sonia: (951) 349-2449",
    email: "",
    state: "AZ",
    city: "Ehrenberg",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Ehrenberg, AZ", "Blythe, CA"])
  },

  // Texas
  {
    name: "DEPENDABLE SHUTTLE",
    phoneNumber: "(956) 555-0201",
    email: "dispatch@dependable.com",
    state: "TX",
    city: "Alvarado",
    status: "available" as const,
    vehicleType: "Van",
    serviceLocations: JSON.stringify(["Alvarado, TX", "Fort Worth, TX", "Cleburne, TX", "Burleson, TX"])
  },
  {
    name: "YNOTME T.S.LLC",
    phoneNumber: "(832) 389-6486",
    email: "",
    state: "TX",
    city: "Houston",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Houston, TX", "Elmendorf, TX", "Laredo, TX", "Converse, TX"])
  },

  // Pennsylvania
  {
    name: "Guardian Angel Rides",
    phoneNumber: "(717) 555-0101",
    email: "contact@guardianangel.com",
    state: "PA",
    city: "Hollidaysburg",
    status: "available" as const,
    vehicleType: "Van",
    serviceLocations: JSON.stringify(["Hollidaysburg, PA", "Altoona, PA", "State College, PA"])
  },
  {
    name: "Shuttle Driver Terry",
    phoneNumber: "(717) 555-0102",
    email: "terry@shuttle.com",
    state: "PA",
    city: "Hollidaysburg",
    status: "available" as const,
    vehicleType: "SUV",
    serviceLocations: JSON.stringify(["Hollidaysburg, PA", "Johnstown, PA", "Pittsburgh, PA"])
  },
  {
    name: "Shuttle Driver Steve",
    phoneNumber: "(717) 555-0103",
    email: "steve@shuttle.com",
    state: "PA",
    city: "Hollidaysburg",
    status: "on_trip" as const,
    vehicleType: "Van",
    serviceLocations: JSON.stringify(["Hollidaysburg, PA", "Bedford, PA", "Altoona, PA"])
  },

  // Georgia
  {
    name: "Grace and Mercy Transportation",
    phoneNumber: "(404) 555-0301",
    email: "info@gracemercy.com",
    state: "GA",
    city: "Atlanta",
    status: "available" as const,
    vehicleType: "Van",
    serviceLocations: JSON.stringify(["Atlanta, GA", "Marietta, GA", "Decatur, GA", "Sandy Springs, GA"])
  },
  {
    name: "A Place of Peace Personal Care",
    phoneNumber: "(404) 555-0302",
    email: "contact@placeofpeace.com",
    state: "GA",
    city: "Atlanta",
    status: "on_trip" as const,
    vehicleType: "SUV",
    serviceLocations: JSON.stringify(["Atlanta, GA", "Buckhead, GA", "East Point, GA"])
  },

  // Indiana
  {
    name: "Comfort Driver Transport",
    phoneNumber: "(574) 263-5434",
    email: "",
    state: "IN",
    city: "Elkhart",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Elkhart, IN", "100 mile radius of Elkhart"])
  },
  {
    name: "Divine Transportation",
    phoneNumber: "(574) 218-1024",
    email: "",
    state: "IN",
    city: "Elkhart",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Elkhart, IN"])
  },

  // Ohio
  {
    name: "Teds Taxi Cincinnati",
    phoneNumber: "(859) 588-1518",
    email: "",
    state: "OH",
    city: "Cincinnati",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Cincinnati, OH", "Lexington, KY", "Cynthiana, KY"])
  },
  {
    name: "Jeff in Springfield OH",
    phoneNumber: "(937) 624-9093",
    email: "",
    state: "OH",
    city: "Springfield",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Springfield, OH"])
  },
  {
    name: "Rides in Ohio",
    phoneNumber: "(419) 203-8097",
    email: "",
    state: "OH",
    city: "Delphos",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Delphos, OH"])
  },
  {
    name: "Youngstown Oh Area Shuttle",
    phoneNumber: "330-937-0720",
    email: "",
    state: "OH",
    city: "Youngstown",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Youngstown, OH"])
  },
  {
    name: "Rick Hook",
    phoneNumber: "814-661-2221",
    email: "",
    state: "PA",
    city: "Dubois",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Dubois, PA"])
  },

  // North Carolina
  {
    name: "Bernard/Uber",
    phoneNumber: "704-431-9941",
    email: "",
    state: "NC",
    city: "Salisbury",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Salisbury, NC", "Charlotte, NC", "Greensboro, NC", "Winston Salem, NC"])
  },

  // Texas (additional)
  {
    name: "Denton Transportation",
    phoneNumber: "214-574-0988",
    email: "",
    state: "TX",
    city: "Denton",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Denton, TX", "Multiple points in Texas"])
  },

  // Nebraska
  {
    name: "Gina O - Uber Driver",
    phoneNumber: "402-312-8417",
    email: "",
    state: "NE",
    city: "Omaha",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Omaha, NE", "100 mile radius of Omaha"])
  },

  // Alabama
  {
    name: "RRRides Birmingham Alabama",
    phoneNumber: "256-375-8335",
    email: "",
    state: "AL",
    city: "Birmingham",
    status: "available" as const,
    vehicleType: "Corporate Sprinters, SUVs, Sedans",
    serviceLocations: JSON.stringify(["Birmingham, AL", "Surrounding Area"])
  },

  // Georgia (additional)
  {
    name: "Ms. Wobbles",
    phoneNumber: "706-483-9552",
    email: "",
    state: "GA",
    city: "Dalton",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Dalton, GA", "Nashville, TN", "Knoxville, TN", "Atlanta, GA"])
  },

  // Tennessee
  {
    name: "James in Chattanooga",
    phoneNumber: "423-241-2888",
    email: "",
    state: "TN",
    city: "Chattanooga",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Chattanooga, TN"])
  },
  {
    name: "Personal Shuttle Service Loudon",
    phoneNumber: "865-680-9518",
    email: "",
    state: "TN",
    city: "Loudon",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Loudon, TN", "Knoxville, TN", "Surrounding areas"])
  },
  {
    name: "Knoxville Area Shuttle",
    phoneNumber: "865-454-7591",
    email: "",
    state: "TN",
    city: "Knoxville",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Knoxville, TN", "50-60 mile radius from Knoxville"])
  },

  // New York
  {
    name: "D&G Taxi Service",
    phoneNumber: "315-317-9324",
    email: "",
    state: "NY",
    city: "Waterloo",
    status: "available" as const,
    vehicleType: "Taxi",
    serviceLocations: JSON.stringify(["Waterloo, NY"])
  },

  // Connecticut
  {
    name: "Shamir",
    phoneNumber: "860-576-7491",
    email: "",
    state: "CT",
    city: "Moosup",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Moosup, CT", "Various locations"])
  },

  // Michigan
  {
    name: "Affordable Taxi",
    phoneNumber: "810-881-1777",
    email: "",
    state: "MI",
    city: "Flint",
    status: "available" as const,
    vehicleType: "Taxi",
    serviceLocations: JSON.stringify(["Flint, MI"])
  },

  // Indiana (additional)
  {
    name: "Omar Gary Indiana Taxi",
    phoneNumber: "708-527-6575",
    email: "",
    state: "IN",
    city: "Gary",
    status: "available" as const,
    vehicleType: "Taxi",
    serviceLocations: JSON.stringify(["Gary, IN"])
  },
  {
    name: "Brandy (Linda is the dispatcher)",
    phoneNumber: "574-327-5828",
    email: "",
    state: "IN",
    city: "Goshen",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Goshen, IN", "Bristol, IN", "Elkhart, IN", "South Bend, IN", "Wyoming, MI"])
  },

  // Illinois
  {
    name: "Tony Chicago Transportation",
    phoneNumber: "815-768-6281",
    email: "",
    state: "IL",
    city: "Chicago",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Chicago, IL", "Greater Chicagoland area"])
  },

  // Wisconsin
  {
    name: "Red, White, and Blue Shuttle Service",
    phoneNumber: "262-903-8800",
    email: "",
    state: "WI",
    city: "Lake Geneva",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Lake Geneva, WI", "Delavan, WI", "Janesville, WI"])
  },
  {
    name: "Flying L Transport",
    phoneNumber: "608-558-0297",
    email: "",
    state: "WI",
    city: "Monroe",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Monroe, WI"])
  },
  {
    name: "Gotta Go Taxi",
    phoneNumber: "715-459-7856",
    email: "gottagotaxi@gmail.com",
    state: "WI",
    city: "Wisconsin Rapids",
    status: "available" as const,
    vehicleType: "Taxi",
    serviceLocations: JSON.stringify(["Wisconsin Rapids, WI"])
  },

  // Iowa
  {
    name: "Shine Transportation LLC",
    phoneNumber: "",
    email: "",
    state: "IA",
    city: "Dubuque",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Dubuque, IA", "Dyersville, IA", "Shullsburg, WI"])
  },
  {
    name: "Matty Cedar Rapids",
    phoneNumber: "319-209-6086",
    email: "",
    state: "IA",
    city: "Cedar Rapids",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Cedar Rapids, IA", "Joliet, IL"])
  },
  {
    name: "Tabor Regional Shuttle Service",
    phoneNumber: "641-590-1602",
    email: "",
    state: "IA",
    city: "Forrest City",
    status: "available" as const,
    vehicleType: "Car and SUV",
    serviceLocations: JSON.stringify(["Forrest City, IA", "Minneapolis, MN", "Des Moines, IA", "125 mile radius"])
  },

  // Missouri
  {
    name: "Christine's Rides",
    phoneNumber: "417-307-9510",
    email: "",
    state: "MO",
    city: "Springfield",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Springfield, MO", "Around Springfield"])
  },
  {
    name: "John's Cab",
    phoneNumber: "573-842-8413",
    email: "",
    state: "MO",
    city: "Missouri",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Missouri"])
  },
  {
    name: "Shuttle Driver Kim",
    phoneNumber: "816-294-8318",
    email: "",
    state: "MO",
    city: "St Joseph",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["St Joseph, MO"])
  },
  {
    name: "KC Shuttle Link",
    phoneNumber: "",
    email: "",
    state: "MO",
    city: "Kansas City",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Kansas City, MO", "Kansas City, KS", "Terminals and lots across KC area"])
  },
  {
    name: "Shuttlesworth Jackson",
    phoneNumber: "816-499-0855",
    email: "",
    state: "MO",
    city: "Kansas City",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Kansas City, MO", "KC metro area"])
  },

  // Virginia
  {
    name: "Khan",
    phoneNumber: "540-566-7566",
    email: "",
    state: "VA",
    city: "Roanoke",
    status: "available" as const,
    vehicleType: "Car",
    serviceLocations: JSON.stringify(["Roanoke, VA", "Dublin, VA"])
  },

  // Arkansas
  {
    name: "Joey (Lyft)",
    phoneNumber: "479-431-9503",
    email: "",
    state: "AR",
    city: "Fort Smith",
    status: "available" as const,
    vehicleType: "Jeep Compass",
    serviceLocations: JSON.stringify(["Fort Smith, AR"])
  },

  // Texas (additional)
  {
    name: "Mike",
    phoneNumber: "210-914-2033",
    email: "",
    state: "TX",
    city: "San Antonio",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["San Antonio, TX", "Laredo, TX", "Surrounding areas"])
  },

  // Kansas
  {
    name: "Paul in Wichita",
    phoneNumber: "316-644-0373",
    email: "",
    state: "KS",
    city: "Wichita",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Wichita, KS", "250 mile radius", "Tulsa, OK", "Oklahoma City, OK", "Independence, KS", "Salina, KS", "Kansas City, MO"])
  },

  // New Mexico
  {
    name: "Driver Samantha",
    phoneNumber: "575-631-1117",
    email: "",
    state: "NM",
    city: "Hobbs",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Hobbs, NM"])
  },

  // South Dakota
  {
    name: "Lake Area Taxi",
    phoneNumber: "",
    email: "",
    state: "SD",
    city: "Watertown",
    status: "available" as const,
    vehicleType: "Taxi/Shuttle",
    serviceLocations: JSON.stringify(["Watertown, SD", "South Dakota", "North Dakota", "Minnesota"])
  },
  {
    name: "David in SD",
    phoneNumber: "605-310-8121",
    email: "",
    state: "SD",
    city: "Sioux Falls",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Sioux Falls, SD"])
  },

  // Nebraska (additional)
  {
    name: "Transit North Platte NE",
    phoneNumber: "308-539-7217",
    email: "",
    state: "NE",
    city: "North Platte",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["North Platte, NE"])
  },

  // Utah
  {
    name: "Brenda",
    phoneNumber: "801-427-2361",
    email: "",
    state: "UT",
    city: "Provo",
    status: "available" as const,
    vehicleType: "Lyft, Private Shuttle",
    serviceLocations: JSON.stringify(["Provo, UT", "Salt Lake City, UT", "100 mile radius"])
  },

  // Montana
  {
    name: "Uber/Lyft Driver Polson",
    phoneNumber: "417-307-9510",
    email: "",
    state: "MT",
    city: "Polson",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Polson, MT", "Around Montana"])
  },

  // Oregon
  {
    name: "Amanda's Taxi Service",
    phoneNumber: "503-851-0907",
    email: "",
    state: "OR",
    city: "Portland",
    status: "available" as const,
    vehicleType: "Taxi",
    serviceLocations: JSON.stringify(["Portland, OR", "Salem, OR", "Surrounding areas"])
  },

  // California (additional)
  {
    name: "Driver Ryan",
    phoneNumber: "530-557-5423",
    email: "",
    state: "CA",
    city: "Grass Valley",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Grass Valley, CA"])
  },

  // Ohio (additional)
  {
    name: "Millie",
    phoneNumber: "937-408-6841",
    email: "",
    state: "OH",
    city: "Dayton",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Dayton, OH"])
  },
  {
    name: "Mark",
    phoneNumber: "419-203-8097",
    email: "",
    state: "OH",
    city: "Springfield",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Springfield, OH", "Lima, OH", "Chillicothe, OH", "Fort Wayne, IN"])
  },

  // Illinois (additional)
  {
    name: "Gary",
    phoneNumber: "815-257-2058",
    email: "",
    state: "IL",
    city: "Streator",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Streator, IL"])
  },

  // Florida
  {
    name: "Rudy Shuttle",
    phoneNumber: "404-573-0584",
    email: "",
    state: "FL",
    city: "Ocala",
    status: "available" as const,
    vehicleType: "Personal Shuttle Service",
    serviceLocations: JSON.stringify(["Ocala, FL"])
  },
];

async function seed() {
  console.log("🌱 Starting database seed...");

  // Clear all existing drivers
  await prisma.driver.deleteMany({});
  console.log("🗑️  Cleared all existing drivers");

  // Create real drivers
  for (const driver of realDrivers) {
    await prisma.driver.create({
      data: driver,
    });
  }

  console.log(`✅ Created ${realDrivers.length} real driveaway companies`);
  console.log("🎉 Seed completed successfully!");
  console.log("\n📝 To add more companies:");
  console.log("   1. Find companies on driveawayguide.com map");
  console.log("   2. Use the Admin Dashboard in the app to add them");
  console.log("   3. Or add them to this seed file and run: bun run prisma/seed.ts");
}

seed()
  .catch((error) => {
    console.error("❌ Seed failed:", error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
