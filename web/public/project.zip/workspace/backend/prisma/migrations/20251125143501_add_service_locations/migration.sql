-- AlterTable
ALTER TABLE "driver" ADD COLUMN "serviceLocations" TEXT;
