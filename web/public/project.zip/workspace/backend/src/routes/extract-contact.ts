import { Hono } from "hono";
import type { AppType } from "../types";
import Anthropic from "@anthropic-ai/sdk";

const router = new Hono<AppType>();

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
  baseURL: process.env.ANTHROPIC_BASE_URL,
});

// Extract contact info from uploaded screenshot using Claude Vision
router.post("/extract-contact", async (c) => {
  try {
    // Check if API key is configured
    if (!process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_API_KEY.includes('n0tr3al') || process.env.ANTHROPIC_API_KEY === 'sk-ant-api03-gu2gohc4sha1Thohpeep7ro9vie1ikai-n0tr3al') {
      return c.json({
        success: false,
        message: "OCR requires an Anthropic API key. Please add ANTHROPIC_API_KEY to your environment variables in the ENV tab.",
        error: "API key not configured"
      }, 400);
    }

    const body = await c.req.parseBody();
    const image = body['image'];

    if (!image || typeof image === 'string') {
      return c.json({ success: false, error: "No image provided" }, 400);
    }

    // Convert image to base64
    const imageFile = image as File;
    const arrayBuffer = await imageFile.arrayBuffer();
    const base64Image = Buffer.from(arrayBuffer).toString('base64');

    // Determine media type
    const mediaType = imageFile.type || 'image/jpeg';

    // Use Claude to extract contact information
    const message = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 1024,
      messages: [
        {
          role: "user",
          content: [
            {
              type: "image",
              source: {
                type: "base64",
                media_type: mediaType as "image/jpeg" | "image/png" | "image/gif" | "image/webp",
                data: base64Image,
              },
            },
            {
              type: "text",
              text: `Extract the transportation company/driver contact information from this image. Return ONLY a JSON object with these fields:
{
  "name": "company or driver name",
  "phone": "phone number in format (XXX) XXX-XXXX",
  "email": "email if present, otherwise empty string",
  "city": "primary city mentioned",
  "state": "US state code (e.g., TX, PA, GA)",
  "serviceLocations": ["array", "of", "cities", "they", "service"]
}

If any field is not found, use empty string for text fields or empty array for serviceLocations. Return ONLY valid JSON, no other text.`,
            },
          ],
        },
      ],
    });

    // Parse the response
    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';

    // Extract JSON from response (in case Claude adds extra text)
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return c.json({
        success: false,
        error: "Could not extract structured data from image",
      }, 400);
    }

    const extractedData = JSON.parse(jsonMatch[0]);

    return c.json({
      success: true,
      message: "Contact information extracted successfully!",
      ...extractedData,
    });
  } catch (error) {
    console.error("Failed to extract contact:", error);
    return c.json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to process image"
    }, 500);
  }
});

export { router as extractContactRouter };
