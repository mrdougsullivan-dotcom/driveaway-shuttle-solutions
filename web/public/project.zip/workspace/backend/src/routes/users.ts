import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { type AppType } from "../types";
import { db } from "../db";

const usersRouter = new Hono<AppType>();

// Response schemas
const userSchema = z.object({
  id: z.string(),
  email: z.string(),
  name: z.string().nullable(),
  emailVerified: z.boolean(),
  image: z.string().nullable(),
  createdAt: z.string(),
  updatedAt: z.string(),
});

// Request schemas
const createUserRequestSchema = z.object({
  email: z.string().email(),
  name: z.string().optional(),
  password: z.string().min(8),
});

const updateUserRequestSchema = z.object({
  email: z.string().email().optional(),
  name: z.string().optional(),
  emailVerified: z.boolean().optional(),
});

// ============================================
// GET /api/users - Get all users
// ============================================
usersRouter.get("/", async (c) => {
  console.log("👥 [Users] GET all users request received");

  try {
    const users = await db.user.findMany({
      orderBy: {
        createdAt: "desc",
      },
    });

    console.log(`✅ [Users] Found ${users.length} users`);

    return c.json({
      users: users.map((u) => ({
        id: u.id,
        email: u.email,
        name: u.name,
        emailVerified: u.emailVerified,
        image: u.image,
        createdAt: u.createdAt.toISOString(),
        updatedAt: u.updatedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error("❌ [Users] Error fetching users:", error);
    return c.json({ error: "Failed to fetch users" }, 500);
  }
});

// ============================================
// GET /api/users/:id - Get specific user
// ============================================
usersRouter.get("/:id", async (c) => {
  const id = c.req.param("id");
  console.log(`👤 [Users] GET user ${id} request received`);

  try {
    const user = await db.user.findUnique({
      where: { id },
    });

    if (!user) {
      console.log(`❌ [Users] User ${id} not found`);
      return c.json({ error: "User not found" }, 404);
    }

    console.log(`✅ [Users] Found user ${id}`);

    return c.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        emailVerified: user.emailVerified,
        image: user.image,
        createdAt: user.createdAt.toISOString(),
        updatedAt: user.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error("❌ [Users] Error fetching user:", error);
    return c.json({ error: "Failed to fetch user" }, 500);
  }
});

// ============================================
// POST /api/users - Create new user
// ============================================
usersRouter.post("/", zValidator("json", createUserRequestSchema), async (c) => {
  const data = c.req.valid("json");
  console.log(`👥 [Users] POST create user request received for ${data.email}`);

  try {
    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email: data.email },
    });

    if (existingUser) {
      console.log(`❌ [Users] User with email ${data.email} already exists`);
      return c.json({ error: "User with this email already exists" }, 400);
    }

    // Create user
    const user = await db.user.create({
      data: {
        id: crypto.randomUUID(),
        email: data.email,
        name: data.name || null,
        emailVerified: false,
        image: null,
      },
    });

    // Create password account for the user
    await db.account.create({
      data: {
        id: crypto.randomUUID(),
        accountId: user.id,
        providerId: "credential",
        userId: user.id,
        password: data.password, // In production, this should be hashed
      },
    });

    console.log(`✅ [Users] Created user ${user.id}`);

    return c.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        emailVerified: user.emailVerified,
        image: user.image,
        createdAt: user.createdAt.toISOString(),
        updatedAt: user.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error("❌ [Users] Error creating user:", error);
    return c.json({ error: "Failed to create user" }, 500);
  }
});

// ============================================
// PATCH /api/users/:id - Update user
// ============================================
usersRouter.patch("/:id", zValidator("json", updateUserRequestSchema), async (c) => {
  const id = c.req.param("id");
  const data = c.req.valid("json");
  console.log(`👤 [Users] PATCH update user ${id} request received`);

  try {
    const user = await db.user.findUnique({
      where: { id },
    });

    if (!user) {
      console.log(`❌ [Users] User ${id} not found`);
      return c.json({ error: "User not found" }, 404);
    }

    const updatedUser = await db.user.update({
      where: { id },
      data: {
        email: data.email,
        name: data.name,
        emailVerified: data.emailVerified,
      },
    });

    console.log(`✅ [Users] Updated user ${id}`);

    return c.json({
      user: {
        id: updatedUser.id,
        email: updatedUser.email,
        name: updatedUser.name,
        emailVerified: updatedUser.emailVerified,
        image: updatedUser.image,
        createdAt: updatedUser.createdAt.toISOString(),
        updatedAt: updatedUser.updatedAt.toISOString(),
      },
    });
  } catch (error) {
    console.error("❌ [Users] Error updating user:", error);
    return c.json({ error: "Failed to update user" }, 500);
  }
});

// ============================================
// DELETE /api/users/:id - Delete user
// ============================================
usersRouter.delete("/:id", async (c) => {
  const id = c.req.param("id");
  console.log(`🗑️ [Users] DELETE user ${id} request received`);

  try {
    const user = await db.user.findUnique({
      where: { id },
    });

    if (!user) {
      console.log(`❌ [Users] User ${id} not found`);
      return c.json({ error: "User not found" }, 404);
    }

    // Delete user (cascade will handle accounts, sessions, etc.)
    await db.user.delete({
      where: { id },
    });

    console.log(`✅ [Users] Deleted user ${id}`);

    return c.json({ success: true });
  } catch (error) {
    console.error("❌ [Users] Error deleting user:", error);
    return c.json({ error: "Failed to delete user" }, 500);
  }
});

export { usersRouter };
