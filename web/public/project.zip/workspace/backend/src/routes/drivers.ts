import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import {
  type GetDriversResponse,
  type GetStatesResponse,
  type GetCitiesResponse,
  type GetDriverResponse,
  createDriverRequestSchema,
  type CreateDriverResponse,
} from "@/shared/contracts";
import { normalizeState, US_STATES } from "@/shared/states";
import { type AppType } from "../types";
import { db } from "../db";

const driversRouter = new Hono<AppType>();

// Admin password - simple authentication for write operations
const ADMIN_PASSWORD = "admin2025";

// Middleware to check admin password for write operations
const requireAdmin = async (c: any, next: any) => {
  const authHeader = c.req.header("x-admin-password");

  if (!authHeader || authHeader !== ADMIN_PASSWORD) {
    console.log("❌ [Drivers] Unauthorized admin access attempt");
    return c.json({ error: "Unauthorized - Invalid admin password" }, 401);
  }

  await next();
};

// ============================================
// GET /api/drivers - Get all drivers
// ============================================
driversRouter.get("/", async (c) => {
  console.log("🚗 [Drivers] GET all drivers request received");

  try {
    const drivers = await db.driver.findMany({
      orderBy: [
        { state: "asc" },
        { city: "asc" },
        { name: "asc" },
      ],
    });

    console.log(`✅ [Drivers] Found ${drivers.length} drivers`);

    return c.json({
      drivers: drivers.map(d => ({
        ...d,
        status: d.status as "available" | "on_trip" | "offline",
        createdAt: d.createdAt.toISOString(),
        updatedAt: d.updatedAt.toISOString(),
      })),
    } satisfies GetDriversResponse);
  } catch (error) {
    console.error("❌ [Drivers] Error fetching drivers:", error);
    return c.json({ error: "Failed to fetch drivers" }, 500);
  }
});

// ============================================
// GET /api/drivers/states - Get states with driver counts
// ============================================
driversRouter.get("/states", async (c) => {
  console.log("🗺️ [Drivers] GET states request received");

  try {
    const drivers = await db.driver.findMany({
      select: {
        state: true,
      },
    });

    // Group drivers by state and count them
    const stateCounts = drivers.reduce((acc, driver) => {
      acc[driver.state] = (acc[driver.state] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Map to response format with state names
    const states = Object.entries(stateCounts).map(([code, count]) => ({
      code,
      name: US_STATES[code] || code,
      driverCount: count,
    })).sort((a, b) => a.name.localeCompare(b.name));

    console.log(`✅ [Drivers] Found ${states.length} states with drivers`);

    return c.json({ states } satisfies GetStatesResponse);
  } catch (error) {
    console.error("❌ [Drivers] Error fetching states:", error);
    return c.json({ error: "Failed to fetch states" }, 500);
  }
});

// ============================================
// GET /api/drivers/cities/:state - Get cities in state with driver counts
// ============================================
driversRouter.get("/cities/:state", async (c) => {
  const state = c.req.param("state");
  console.log(`🏙️ [Drivers] GET cities for state ${state} request received`);

  try {
    const drivers = await db.driver.findMany({
      where: { state },
      select: {
        city: true,
      },
    });

    // Group drivers by city and count them
    const cityCounts = drivers.reduce((acc, driver) => {
      acc[driver.city] = (acc[driver.city] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    // Map to response format
    const cities = Object.entries(cityCounts).map(([name, count]) => ({
      name,
      driverCount: count,
    })).sort((a, b) => a.name.localeCompare(b.name));

    console.log(`✅ [Drivers] Found ${cities.length} cities in ${state}`);

    return c.json({ cities } satisfies GetCitiesResponse);
  } catch (error) {
    console.error("❌ [Drivers] Error fetching cities:", error);
    return c.json({ error: "Failed to fetch cities" }, 500);
  }
});

// ============================================
// GET /api/drivers/:id - Get specific driver
// ============================================
driversRouter.get("/:id", async (c) => {
  const id = c.req.param("id");
  console.log(`🚗 [Drivers] GET driver ${id} request received`);

  try {
    const driver = await db.driver.findUnique({
      where: { id },
    });

    if (!driver) {
      console.log(`❌ [Drivers] Driver ${id} not found`);
      return c.json({ error: "Driver not found" }, 404);
    }

    console.log(`✅ [Drivers] Found driver ${id}`);

    return c.json({
      driver: {
        ...driver,
        status: driver.status as "available" | "on_trip" | "offline",
        createdAt: driver.createdAt.toISOString(),
        updatedAt: driver.updatedAt.toISOString(),
      },
    } satisfies GetDriverResponse);
  } catch (error) {
    console.error("❌ [Drivers] Error fetching driver:", error);
    return c.json({ error: "Failed to fetch driver" }, 500);
  }
});

// ============================================
// POST /api/drivers - Create new driver
// ============================================
driversRouter.post("/", requireAdmin, zValidator("json", createDriverRequestSchema), async (c) => {
  const data = c.req.valid("json");
  console.log(`🚗 [Drivers] POST create driver request received for ${data.name}`);

  // Normalize state input (accepts "VA", "va", "Virginia", "virginia", etc.)
  const normalizedState = normalizeState(data.state);
  if (!normalizedState) {
    console.log(`❌ [Drivers] Invalid state: ${data.state}`);
    return c.json({ error: `Invalid state: ${data.state}. Please use state abbreviation (e.g., VA) or full name (e.g., Virginia)` }, 400);
  }

  try {
    // Convert comma-separated serviceLocations to JSON array if provided
    let serviceLocationsJSON = null;
    if (data.serviceLocations && data.serviceLocations.trim()) {
      const locations = data.serviceLocations
        .split(',')
        .map(loc => loc.trim())
        .filter(loc => loc.length > 0);
      serviceLocationsJSON = JSON.stringify(locations);
    }

    const driver = await db.driver.create({
      data: {
        name: data.name,
        phoneNumber: data.phoneNumber || null,
        email: data.email || null,
        state: normalizedState, // Use normalized state code (e.g., "VA")
        city: data.city,
        status: data.status,
        vehicleType: data.vehicleType || null,
        serviceLocations: serviceLocationsJSON,
      },
    });

    console.log(`✅ [Drivers] Created driver ${driver.id} in ${normalizedState}`);

    return c.json({
      driver: {
        ...driver,
        status: driver.status as "available" | "on_trip" | "offline",
        createdAt: driver.createdAt.toISOString(),
        updatedAt: driver.updatedAt.toISOString(),
      },
    } satisfies CreateDriverResponse);
  } catch (error) {
    console.error("❌ [Drivers] Error creating driver:", error);
    return c.json({ error: "Failed to create driver" }, 500);
  }
});

// ============================================
// PATCH /api/drivers/:id - Update driver
// ============================================
driversRouter.patch("/:id", requireAdmin, zValidator("json", createDriverRequestSchema), async (c) => {
  const id = c.req.param("id");
  const data = c.req.valid("json");
  console.log(`✏️ [Drivers] PATCH update driver ${id} request received`);

  // Normalize state input
  const normalizedState = normalizeState(data.state);
  if (!normalizedState) {
    console.log(`❌ [Drivers] Invalid state: ${data.state}`);
    return c.json({ error: `Invalid state: ${data.state}. Please use state abbreviation (e.g., VA) or full name (e.g., Virginia)` }, 400);
  }

  try {
    // Check if driver exists
    const existingDriver = await db.driver.findUnique({
      where: { id },
    });

    if (!existingDriver) {
      console.log(`❌ [Drivers] Driver ${id} not found`);
      return c.json({ error: "Driver not found" }, 404);
    }

    // Convert comma-separated serviceLocations to JSON array if provided
    let serviceLocationsJSON = null;
    if (data.serviceLocations && data.serviceLocations.trim()) {
      const locations = data.serviceLocations
        .split(',')
        .map(loc => loc.trim())
        .filter(loc => loc.length > 0);
      serviceLocationsJSON = JSON.stringify(locations);
    }

    const updatedDriver = await db.driver.update({
      where: { id },
      data: {
        name: data.name,
        phoneNumber: data.phoneNumber || null,
        email: data.email || null,
        state: normalizedState,
        city: data.city,
        status: data.status,
        vehicleType: data.vehicleType || null,
        serviceLocations: serviceLocationsJSON,
      },
    });

    console.log(`✅ [Drivers] Updated driver ${id}`);

    return c.json({
      driver: {
        ...updatedDriver,
        status: updatedDriver.status as "available" | "on_trip" | "offline",
        createdAt: updatedDriver.createdAt.toISOString(),
        updatedAt: updatedDriver.updatedAt.toISOString(),
      },
    } satisfies CreateDriverResponse);
  } catch (error) {
    console.error("❌ [Drivers] Error updating driver:", error);
    return c.json({ error: "Failed to update driver" }, 500);
  }
});

// ============================================
// DELETE /api/drivers/:id - Delete driver
// ============================================
driversRouter.delete("/:id", requireAdmin, async (c) => {
  const id = c.req.param("id");
  console.log(`🗑️ [Drivers] DELETE driver ${id} request received`);

  try {
    const driver = await db.driver.findUnique({
      where: { id },
    });

    if (!driver) {
      console.log(`❌ [Drivers] Driver ${id} not found`);
      return c.json({ error: "Driver not found" }, 404);
    }

    await db.driver.delete({
      where: { id },
    });

    console.log(`✅ [Drivers] Deleted driver ${id}`);

    return c.json({ success: true });
  } catch (error) {
    console.error("❌ [Drivers] Error deleting driver:", error);
    return c.json({ error: "Failed to delete driver" }, 500);
  }
});

export { driversRouter };
